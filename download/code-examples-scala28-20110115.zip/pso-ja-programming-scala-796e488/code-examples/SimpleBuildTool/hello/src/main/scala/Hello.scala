/** 最初のサンプル */
object Hello {
  def main(args:Array[String]):Unit = println("こんにちは!! Scala")
}