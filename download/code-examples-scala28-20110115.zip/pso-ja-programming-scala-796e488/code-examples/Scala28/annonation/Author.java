// code-examples/Scala28/annonation/Author.java
public @interface Author
{
     String name();
}
