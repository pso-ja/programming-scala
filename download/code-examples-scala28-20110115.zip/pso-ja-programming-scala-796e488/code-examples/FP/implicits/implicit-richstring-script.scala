// code-examples/FP/implicits/implicit-richstring-script.scala
val name: String = "scala"
println(name.capitalize.reverse)
println(name.capitalize.getClass())
println(name.capitalize.reverse.getClass())
