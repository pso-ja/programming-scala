object Adder {
  /** */
  def add(a:Int,b:Int):Int =  a + b 
}