// code-examples/Scala28/package/package-v28.scala
package foo

class Foo
