// src/code-examples/Scala28/package/package-new-v28.scala
package foo
package bar

// foo.bar.Barの宣言と同じ
class Bar extends Foo
