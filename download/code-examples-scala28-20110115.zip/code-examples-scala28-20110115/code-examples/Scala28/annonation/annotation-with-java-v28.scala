// code-examples/Scala28/annonation/annotation-with-java-v28.scala
@Book(name = "Programming Scala", 
      authors = Array(new Author(name = "Dean Wrampler"),
   	   new Author(name = "Alex Payne")))
class ProgrammingScala {}
