// code-examples/Scala28/annonation/Book.java
public @interface Book {
    String name();
    Author[] authors();
}