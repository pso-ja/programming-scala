// code-examples/Traits/ui2/clickable.scala

package ui2

trait Clickable {
  def click()
}
