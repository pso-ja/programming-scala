// code-examples/AdvOOP/ui3/clickable.scala
package ui3

trait Clickable {
    def click()
}
