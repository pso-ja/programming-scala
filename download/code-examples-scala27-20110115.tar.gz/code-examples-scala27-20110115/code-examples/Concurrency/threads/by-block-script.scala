// code-examples/Concurrency/threads/by-block-script.scala

new Thread { println("this will run in a new thread") }