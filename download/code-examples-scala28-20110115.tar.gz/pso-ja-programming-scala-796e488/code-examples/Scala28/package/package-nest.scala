// code-examples/Scala28/package/package-nest.scala
package foo {
  package bar {
    class Bar
  }
}
