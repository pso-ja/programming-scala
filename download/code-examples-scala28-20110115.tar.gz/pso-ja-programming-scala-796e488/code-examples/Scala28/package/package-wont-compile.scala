// code-examples/Scala28/package/package-wont-compile.scala
package foo.bar

class Bar extends Foo // 2.7ではコンパイルできるが、2.8コンパイルできない。
