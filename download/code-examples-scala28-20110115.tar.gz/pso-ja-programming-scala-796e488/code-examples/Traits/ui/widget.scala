// code-examples/Traits/ui/widget.scala

package ui

abstract class Widget