// code-examples/XML/writing/config.scala
// "Fake" Config object for the atom-feed.scala example.

object Config {
  val atomPath = "atom-example.xml"
}
