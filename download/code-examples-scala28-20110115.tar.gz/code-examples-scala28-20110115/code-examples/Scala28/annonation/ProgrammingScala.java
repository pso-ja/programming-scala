
@Book(name = "Programming Scala", 
      authors = {@Author(name = "Dean Wrampler"),@Author(name = "Alex Payne")})
public class ProgrammingScala { }